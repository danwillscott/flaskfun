# from flask import Flask, render_template, request, redirect, session  # Import Flask to allow us to create our app.
# app = Flask(__name__)    # Global variable __name__ tells Flask whether or not we are running the file
#                          # directly, or importing it as a module.
#           # The "@" symbol designates a "decorator" which attaches the following # function to the '/' route. This means that whenever we send a request to
# app.secret_key = "SKEY12345"                     
                      
# @app.route('/')
# def index():		# localhost:5000/ for index.html
# 	return render_template('index.html')




# TESTING AREA!!!

# import Flask
from flask import Flask, render_template, redirect, request, session, flash
# the "re" module will let us perform some regular expression operations
import re
# create a regular expression object that we can use run operations on




EMAIL_REGEX = re.compile(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)")

PASWORD_REGEX = re.compile(r'((?=.+\d)(?=.+[a-z])(?=.+[A-Z]).{8,})', re.MULTILINE) # needs to be g and m
# PASWORD_REGEX = re.compile(r'[0-1a-zA-Z]')
app = Flask(__name__)
app.secret_key = "ThisIsSecret!"



# FUNCTION LOCATIONS #


# Flash message handler

# Name length validation TODO: add number and special char check
def validateNames(userName, nametype):
	if len(userName) < 1:
		flash("Enter A Valid {} Name".format(nametype), "error")
		return False
	else:
		return True #TODO FIX THIS

def pwdValid(formData, formData2):
	if formData == formData2:
		pass
		aMatch = PASWORD_REGEX.match(formData)
		print aMatch
		if len(formData) < 8:
			flash("Password to short!", 'error') #Call back to flash handler
			return False
		elif PASWORD_REGEX.match(formData) == None:
			flash('Password to weak!!!', 'error')
			return False
		else:
			flash("Password Good!", "pass")
			return True
	else:
		flash("Password doesn't match!", 'error')
		return False



def emailValid(formData):
	print EMAIL_REGEX.match(formData)
	if len(formData) < 1:
		flash("Email cannot be blank!", 'error')
	elif EMAIL_REGEX.match(formData) == None:
		flash("Invalid Email Address!", 'error')
	else:
		flash("Email Meets Requirements!", "pass")
	return True



# END FUNCTION LOCATIONS #

@app.route('/', methods=['GET'])
def index():
	return render_template("index.html")



@app.route('/process', methods=['POST'])
def submit():
	validateNames(request.form['first'], "First")
	validateNames(request.form['last'], "Last")
	pwdValid(request.form['password'], request.form['confirm_password'])
	emailValid(request.form['email'])
	if validateNames(request.form['first'], "First") and validateNames(request.form['last'], "Last") and emailValid(request.form['email']) and pwdValid(request.form['password'], request.form['confirm_password']):
		session["first"] = request.form['first']
		session["last"] = request.form['last']
		session["email"] = request.form['email']
		return render_template('index.html', welcome="Hello", fName=session['first'], lName=session["last"], email=session["email"])

	return redirect('/')






# Building a standard name function that handles validation
    # if len(request.form['email']) < 1:
    #     flash("Email cannot be blank!")
    # elif not EMAIL_REGEX.match(request.form['email']):
    #     flash("Invalid Email Address!")
    # else:
    #     flash("Success!")
    # return redirect('/')










app.run(debug=True) # Run the app in debug mode if debug is set to True.     